# Raunak Yadav × Music Bot

A Telegram group music-bot starter with:
- /play for direct HTTP(S) audio streams
- /pause /resume /skip /stop
- /queue /nowplaying
- Channel button/support
- Render free-tier deployment files
- Docker + FFmpeg

## Important
This build deliberately accepts direct audio URLs or audio you are authorized to stream. It does not scrape/download copyrighted music from YouTube or other services.

## Required environment variables
BOT_TOKEN=your BotFather token
API_ID=your Telegram API ID
API_HASH=your Telegram API hash
SESSION_STRING=your Pyrogram user session string
CHANNEL_USERNAME=your_channel_username

Never post your bot token, API hash, or session string publicly.

## Local run
1. Install Python 3.10+.
2. Install FFmpeg.
3. `pip install -r requirements.txt`
4. Set the environment variables.
5. `python bot.py`

## Render
Render currently offers free web services, but free services can spin down after 15 minutes without inbound traffic and have usage limits. This means free hosting is suitable for testing/hobby use, not guaranteed 24/7 production uptime.

Create a Render Web Service from this repository, choose the Free plan, and add the environment variables in the dashboard.

## Telegram setup
1. Create a bot with @BotFather and copy the token.
2. Get API_ID and API_HASH from Telegram's developer portal.
3. The user account represented by SESSION_STRING must be allowed to join/speak in the group's voice chat.
4. Add the bot to your group as an admin if you want it to manage bot messages.
5. Add your channel username in CHANNEL_USERNAME.

## Example
/play https://example.com/your-authorized-audio.mp3
